package FinalProject;

import javax.swing.*;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.*;

public class test extends JFrame {
  private JTextField tfName = new JTextField(20);
  private JTextField tfPassword = new JTextField(20);
  

  // Button for sending a student to the server
  private JButton btRegister = new JButton("Register to the Server");

  // Host name or ip
  String host = "localhost";

  public test() {
	  super("ClientHandler");
	  
	  JPanel mainPanel = new JPanel();
	  mainPanel.setLayout(new BorderLayout());
	  
	  JPanel infoPanel = new JPanel();
	  infoPanel.setLayout(new GridLayout(6,2));
	  infoPanel.add(new JLabel("Name"));
	  infoPanel.add(tfName);
	  infoPanel.add(new JLabel("Password"));
	  infoPanel.add(tfPassword);

	  
	  mainPanel.add(infoPanel, BorderLayout.CENTER);
	  
	  JPanel controlPanel = new JPanel();
	  controlPanel.add(btRegister);
	  mainPanel.add(controlPanel, BorderLayout.SOUTH);
	  this.add(mainPanel);
	  btRegister.addActionListener(new ButtonListener());
    
	  setSize(450, 200);
  }

  /** Handle button action */
  private class ButtonListener implements ActionListener {
	  
    public void actionPerformed(ActionEvent e) {
      try {
        // Establish connection with the server
        Socket socket = new Socket(host, 8000);

        // Create an output stream to the server
        ObjectOutputStream toServer =
          new ObjectOutputStream(socket.getOutputStream());

        // Get text field
        String name = tfName.getText().trim();
        String password = tfPassword.getText().trim();
        
        insertUser(name,password);
        // Create a Student object and send to the server
        RegistrationData s =
          new RegistrationData(name, password);
        toServer.writeObject(s);
      }
      catch (IOException ex) {
        ex.printStackTrace();
      }
      
      
    }

  }
  
  
  public static void main(String[] args) {

	  test sc = new test();
	  sc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  sc.setVisible(true);
  }
  
  private static void insertUser(String name, String password) {
      // MySQL connection
      String jdbcURL = "jdbc:mysql://localhost:3306/projectdb";
      String dbUser = "root";
      String dbPassword = "Ji394su3*";

      try (Connection con = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
          String query = "INSERT INTO customer (name, password) VALUES (?, ?)";
          try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
              preparedStatement.setString(1, name);
              preparedStatement.setString(2, password);
              preparedStatement.executeUpdate();
          }
      } catch (SQLException e) {
          e.printStackTrace();
      }
  }
}