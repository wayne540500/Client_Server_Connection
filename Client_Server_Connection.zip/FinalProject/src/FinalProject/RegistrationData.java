package FinalProject;

import java.io.Serializable;

public class RegistrationData implements Serializable {
    private String name;
    private String password;

    public RegistrationData(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
    public String toString() {
  	  return "ClientAddress: name: " + this.name + ", password: " + this.password;
    }
}
