package FinalProject;


import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private Socket clientSocket;
    private String registeredName;
    private String registeredPassword;

    public ClientHandler(Socket socket, String name, String password) {
        this.clientSocket = socket;
        this.registeredName = name;
        this.registeredPassword = password;
    }

    @Override
    public void run() {
        try {
            // Handle the order request and interact with the MySQL database
            // Implement order processing and database interactions here
            // Use clientSocket.getInputStream() to read order data
            
            // Here you can read from the clientSocket's input stream and process client requests.
            // For example:
            BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            String clientRequest = reader.readLine();
            System.out.println("Received client request: " + clientRequest);

            // You can also send a response to the client through the clientSocket's output stream.
            PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true);
            writer.println("Response from Server: Your request is being processed.");

            // Close the client socket when done
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
